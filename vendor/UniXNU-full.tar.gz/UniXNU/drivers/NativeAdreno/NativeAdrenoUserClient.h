/* SPDX-License-Identifier: MIT */
#ifndef NATIVE_ADRENO_USERCLIENT_H
#define NATIVE_ADRENO_USERCLIENT_H
#include "NativeAdrenoABI.h"
#include "NativeAdrenoSubmit.h"
#include "NativeAdrenoTimer.h"
#include "NativeAdrenoStatus.h"

/* Kernel-side body of the Adreno user client, deliberately free of IOKit so it
 * can be exercised on a host. The future IOService/IOUserClient wrapper only
 * copies one fixed ABI record in and out and calls these methods; it must not
 * add policy. Handles are this object's own identities, never VM, IOVA or
 * pointer values. A mapping is retirable only through freeBo, which unmaps
 * first and then releases the backing object; both steps must succeed.
 * Up to NativeAdrenoClientMaxObjects live objects and the execbuf's own eight-job limit apply. */
enum : size_t {NativeAdrenoClientMaxObjects=1024,NativeAdrenoClientContiguousFirstBytes=65536};
class NativeAdrenoUserClient final {
    struct Queue {uint32_t id=0;bool active=false;};
    struct Entry {
        NativeAdrenoMemory memory;
        uint64_t handle=0;
        uint64_t mapped=0;
        uint64_t iova=0;
        bool used=false;
        bool mapped_state=false;
        bool unreleasable=false;
        uint32_t metadata_bytes=0;
        uint32_t token=0;
        uint32_t mapping_leases=0;
        char metadata[NativeAdrenoAbiMetadataBytes]{};
    };
    /* Allocated at open(), all-zero is the free state. */
    Entry *entries_=nullptr;
    size_t entry_count_=0;
    Queue queues_[NativeAdrenoAbiMaxQueues]{};
    NativeAdrenoVm *vm_=nullptr;
    NativeAdrenoSubmit *submit_=nullptr;
    NativeAdrenoRing *ring_=nullptr;
    const NativeAdrenoTimer *timer_=nullptr;
    const NativeAdrenoStatus *status_=nullptr;
    const NativeAdrenoAbiDeviceInfo *info_=nullptr;
    uint32_t input_bits_=0,output_bits_=0;
    uint64_t next_handle_=1;
    bool open_=false;
    Entry *find(uint64_t);
    Entry *free();
    static void clear(Entry &);
public:
    NativeAdrenoUserClient()=default;
    ~NativeAdrenoUserClient()=default;
    NativeAdrenoUserClient(const NativeAdrenoUserClient &)=delete;
    NativeAdrenoUserClient &operator=(const NativeAdrenoUserClient &)=delete;
    /* Mounts one already-qualified context. input/output bits describe the
     * active native4K arena and are reported, never guessed. */
    IOReturn open(uint32_t abi_version,NativeAdrenoVm *,NativeAdrenoSubmit *,
        NativeAdrenoRing *,uint32_t input_bits,uint32_t output_bits);
    /* Refuses while any object is live or any job is unobserved. */
    IOReturn close();
    /* Connection teardown: waits for every outstanding job, then unmaps and frees every object, closes every queue and
     * closes the client. The first failure stops it and leaves what remains live; nothing is forced. */
    IOReturn releaseAll(const NativeAdrenoRingClock *,uint32_t timeout_us);
    /* Backing object of a token returned by cpuMap while its lease is held (clientMemoryForType); null otherwise. */
    NativeAdrenoMemory *memoryForToken(uint32_t token);
    IOReturn query(NativeAdrenoAbiParams *);
    IOReturn allocBo(const NativeAdrenoAbiBoAlloc *,NativeAdrenoAbiBoAllocReply *);
    IOReturn mapBo(const NativeAdrenoAbiBoMap *,NativeAdrenoAbiBoMapReply *);
    /* BoImport: pins the caller's pages. Only the IOKit wrapper can call it, with the calling task; dispatch() refuses the method
     * because it has no task (the kernel mailbox path cannot import). */
    IOReturn importBo(const NativeAdrenoAbiBoImport *,void *task,NativeAdrenoAbiBoAllocReply *);
    /* Unmaps if still mapped, then releases the backing object. A failure at
     * either step keeps the entry live and unmapped where possible. */
    IOReturn freeBo(const NativeAdrenoAbiBoFree *);
    IOReturn submit(const NativeAdrenoAbiSubmit *,NativeAdrenoAbiSubmitReply *,
        const NativeAdrenoRingClock *);
    IOReturn cpuMap(const NativeAdrenoAbiBoCpuMap *,NativeAdrenoAbiBoCpuMapReply *);
    IOReturn cpuUnmap(const NativeAdrenoAbiBoCpuUnmap *);
    IOReturn createQueue(NativeAdrenoAbiQueueReply *);
    IOReturn closeQueue(const NativeAdrenoAbiQueue *);
    IOReturn setMetadata(const NativeAdrenoAbiMetadata *);
    IOReturn getMetadata(const NativeAdrenoAbiMetadata *,NativeAdrenoAbiMetadata *);
    IOReturn waitFence(const NativeAdrenoAbiWaitFence *,const NativeAdrenoRingClock *);
    /* One external-method entry: exact record sizes are required, unknown
     * methods are unsupported and no output byte is modified on failure. The
     * IOKit wrapper should only copy these buffers and call this function. */
    IOReturn dispatch(uint32_t method,const void *input,size_t input_size,
        void *output,size_t output_size,const NativeAdrenoRingClock *);
    static size_t inputSize(uint32_t method);
    static size_t outputSize(uint32_t method);
    size_t liveObjects() const;
    /* Optional GPU timestamp source; absent means the method stays unsupported. */
    IOReturn attachTimer(const NativeAdrenoTimer *);
    IOReturn timestamp(NativeAdrenoAbiTimestamp *);
    /* Optional counters; absent means the status method stays unsupported. */
    IOReturn attachStatus(const NativeAdrenoStatus *);
    IOReturn status(NativeAdrenoAbiStatus *);
    /* Optional constant device facts; absent means the method stays unsupported. */
    IOReturn attachDeviceInfo(const NativeAdrenoAbiDeviceInfo *);
    IOReturn deviceInfo(NativeAdrenoAbiDeviceInfo *);
    bool mapped(uint64_t handle);
    /* Backing object of a live handle, for the IOKit wrapper's clientMemoryForType and for kernel self-tests;
     * null for an unknown or unreleasable handle. The client keeps ownership. */
    NativeAdrenoMemory *memoryOf(uint64_t handle);
};
#endif
