/* SPDX-License-Identifier: MIT */
/* Real allocator/layout over host IOKit doubles. No mapping or GMU access. */
#include "XnuMemoryFixture.h"
#include "NativeAdrenoGmuMemory.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#define CHECK(x) do {if(!(x)){std::fprintf(stderr,"line %d: %s\n",__LINE__,#x);std::exit(1);}}while(0)
IOReturn NativeAdrenoQueryCpu4K(NativeAdrenoCpuState *state)
{CHECK(state);*state={};return kIOReturnSuccess;}
IOReturn NativeAdrenoMaintainOwnedPages(void *mapping,size_t bytes,NativeAdrenoCacheOperation op)
{
    CHECK(mapping && bytes && op<=NativeAdrenoInvalidate);
    return kIOReturnSuccess;
}
int main()
{
    {
        NativeAdrenoGmuAllocator allocator;
        CHECK(allocator.allocate(NativeAdrenoGmuDefaultSizes(0x10000))==kIOReturnSuccess && allocator.ready());
        const NativeAdrenoGmuMemoryLayout &layout=allocator.layout();
        /* a6xx_gmu.c at the pinned tree: icache 0x4000, dummy 0x60000000, debug 0x60400000; log and hfi
         * take the lowest free pages after the 16 KiB dummy. */
        CHECK(layout.icache_iova==0x4000);
        CHECK(layout.dummy_iova==0x60000000);
        CHECK(layout.debug_iova==0x60400000);
        CHECK(layout.log_iova==0x60004000);
        CHECK(layout.hfi_iova==0x60008000);
        CHECK(layout.tables_iova==0);
        CHECK(layout.tables_bytes==0x10000);
        CHECK(layout.end_iova==0x60407000);
        CHECK(allocator.icache().bytes()==0xffc000 && allocator.icache().spanCount()==1);
        CHECK(allocator.hfi().bytes()==0x4000 && allocator.tables().spanCount()==1);
        CHECK(allocator.allocate(NativeAdrenoGmuDefaultSizes(0x1000))==kIOReturnBusy);
        CHECK(allocator.release()==kIOReturnSuccess && !allocator.ready());
        CHECK(fixture.live.empty());
    }
    /* Bad sizes, payloads that leave their fixed range, and allocation failure leave nothing behind. */
    {
        NativeAdrenoGmuAllocator allocator;
        CHECK(allocator.allocate(NativeAdrenoGmuDefaultSizes(0))==kIOReturnBadArgument);
        CHECK(allocator.allocate(NativeAdrenoGmuDefaultSizes(0x1001))==kIOReturnBadArgument);
        NativeAdrenoGmuSizes big=NativeAdrenoGmuDefaultSizes(0x10000);
        big.icache=0x60000000;            /* would run into the uncached range */
        CHECK(allocator.allocate(big)==kIOReturnBadArgument);
        big=NativeAdrenoGmuDefaultSizes(0x10000);
        big.hfi=0x400000;                 /* dummy+log+hfi past 0x60400000 */
        CHECK(allocator.allocate(big)==kIOReturnBadArgument);
        big=NativeAdrenoGmuDefaultSizes(0x10000);
        big.debug=0x20000000;             /* past the 2 GiB GMU space */
        CHECK(allocator.allocate(big)==kIOReturnBadArgument);
        CHECK(!allocator.ready() && fixture.live.empty());
    }
    {
        fixture=MemoryFixture{};
        fixture.allocation_fail=true;
        NativeAdrenoGmuAllocator allocator;
        CHECK(allocator.allocate(NativeAdrenoGmuDefaultSizes(0x10000))==kIOReturnNoMemory);
        CHECK(!allocator.ready() && fixture.live.empty());
        fixture.allocation_fail=false;
    }
    std::printf("PASS: 1 fixed a6xx GMU layout allocation and release, 5 size/range refusals, 1 allocation failure and 1 repeat-allocation refusal over host doubles\n");
}
